from django.db import models

class Member(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  age = models.IntegerField(null=True)
  phone = models.IntegerField(null=True)
  joined_date = models.DateField(null=True)

  def __str__(self):
    return f"{self.firstname} {self.lastname}"
  
class Court(models.Model):
  courtname = models.CharField(max_length=255)
  courtcity = models.CharField(max_length=255)
  CHOICES = (
        ('草地', '草地'),
        ('硬地', '硬地'),
        ('泥地', '泥地'),
        ('地毯', '地毯'),
        # 可以繼續增加其他選項
    )
  court_type = models.CharField(max_length=50, choices=CHOICES)

  def __str__(self):
    return f"{self.courtname} {self.courtcity}"